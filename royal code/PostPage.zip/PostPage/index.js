import Navbar from "../Navbar/Navbar";
import Footer from "./footer/footer";
import Postform from "./Postform/Postform";

export default function PostPage() {

    return (
    
    <>
        <Navbar />
        <Postform />
        <Footer />
    </>

    )
}