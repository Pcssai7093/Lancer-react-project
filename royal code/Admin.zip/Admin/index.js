import Navbar from "../Navbar/Navbar";
import Footer from "../PostPage/footer/footer";
import { AdminHome } from "./admin";

export function Admin() {

    return (

        <>
            <Navbar />
            <AdminHome />
            <Footer />
        </>

    )
}